#!/bin/bash
# This file is run on instance start. Output in /var/log/onstart.log

